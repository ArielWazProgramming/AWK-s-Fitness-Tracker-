﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices.ComTypes;

namespace FitnessTracker
{
    public partial class MainPage : Form
    {

        private StreamWriter weightLogger;
        private StreamWriter waterIntakeLogger;
        private StreamWriter physActLogger;
        private StreamWriter dietLogger;

        private string user = "";

        private string dataLocation = @"../../UserData/";

        

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        public MainPage(string user)
        {
            InitializeComponent();

            this.user = user;
            dataLocation += $"{user}Logs";

            this.userLabel.Text += user;
            
            if (!Directory.Exists(dataLocation))
            {
               Directory.CreateDirectory(dataLocation);
            }
        
            List<ListBox> list = new List<ListBox>() { weightListBox, waterListBox, exerciseListBox, dietListBox};

            List<string> pathList = new List<string> { "WeightLog.txt", "WaterIntakeLog.txt", "ActivityLog.txt", "DietLog.txt"};

        

            for (int i = 0; i < 4; i++)
            {
                string path = $@"{dataLocation}/" + pathList[i];
                if (File.Exists(path))
                {
                    using (StreamReader sr = File.OpenText(path))
                    {
                        string s = "";
                        while ((s = sr.ReadLine()) != null)
                        {
                            list[i].Items.Add(s);
                        }
                    }
                }
            }            

        }
        /*private void languageComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var changeLanguage = new ChangeLanguage();
            switch (languageComboBox.SelectedIndex)
            {
                case 0:
                    changeLanguage.UpdateConfig("language", "en");
                    Application.Restart();
                    break;

                case 1:
                    changeLanguage.UpdateConfig("language", "fr-CA");
                    Application.Restart();
                    break;
                case 2:
                    changeLanguage.UpdateConfig("language", "es");
                    Application.Restart();
                    break;
                case 3:
                    changeLanguage.UpdateConfig("language", "ar-SA");
                    Application.Restart();
                    break;
            }
        }*/
        private void MainPage_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void logInput(string pathSRC, string input)
        {
            string path = pathSRC;
            // This text is added only once to the file.
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {
                    sw.WriteLine(input);
                }
            }

            // This text is always added, making the file longer over time
            // if it is not deleted.

            using (StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine(input);
            }
        }

        private void waterIntakeButton_Click(object sender, EventArgs e)
        {
            bmiPanel.Visible = false;
            bmiPanel.Enabled = false;
            weightTrackingPanel.Visible = false;
            weightTrackingPanel.Enabled = false;
            waterIntakePanel.Visible = true;
            waterIntakePanel.Enabled = true;
            exercisePanel.Visible = false;
            exercisePanel.Enabled = false;
            dietPanel.Visible = false;
            dietPanel.Enabled = false;
            defaultPanel.Visible = false;
            defaultPanel.Enabled = false;

        }

        private void calculateBMIButton_Click(object sender, EventArgs e)
        {
            // Get user input from text boxes
            double weight = double.Parse(weightTextBox.Text);
            double height = double.Parse(heightTextBox.Text);

            // convert pounds to kg and cm to meters
            weight *= 0.453592;
            height /= 100;

            // Calculate BMI
            double bmi = weight / (height * height);

            // Display result in text boxes
            bmiResultTextBox.Text = bmi.ToString("F2");

            if (bmi < 18.5)
            {
                classificationButton.Text = "Underweight";
            }
            else if (bmi < 25)
            {
                classificationButton.Text = "Normal weight";
            }
            else if (bmi < 30)
            {
                classificationButton.Text = "Overweight";
            }
            else
            {
                classificationButton.Text = "Obese";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {    
           timeLabel.Text = DateTime.Now.ToString("h:mm:ss tt");
        }

        private void bmiButton_Click(object sender, EventArgs e)
        {
            bmiPanel.Visible = true;
            bmiPanel.Enabled = true;
            weightTrackingPanel.Visible = false;
            weightTrackingPanel.Enabled = false;
            waterIntakePanel.Visible = false;
            waterIntakePanel.Enabled = false;
            exercisePanel.Visible = false;
            exercisePanel.Enabled = false;
            dietPanel.Visible = false;
            dietPanel.Enabled = false;
            defaultPanel.Visible = false;
            defaultPanel.Enabled = false;
        }

        private void weightTracking_Click(object sender, EventArgs e)
        {
            bmiPanel.Visible = false;
            bmiPanel.Enabled = false;
            weightTrackingPanel.Visible = true;
            weightTrackingPanel.Enabled = true;
            waterIntakePanel.Visible = false;
            waterIntakePanel.Enabled = false;
            exercisePanel.Visible = false;
            exercisePanel.Enabled = false;
            dietPanel.Visible = false;
            dietPanel.Enabled = false;
            defaultPanel.Visible = false;
            defaultPanel.Enabled = false;
        }

        private void addWeightButton_Click(object sender, EventArgs e)
        {
            // Declare a variable to hold the parsed weight
            double weight;

            // Try to parse the weight from the text in weightTextBox
            if (Double.TryParse(textBox4.Text, out weight))
            {
                // If the parsing succeeded, add the weight to the ListBox, formatted to two decimal places
                weightListBox.Items.Add(weight.ToString("N2"));

                string path = $@"{dataLocation}/WeightLog.txt";
                /*var output = new FileStream($@"{dataLocation}/WeightLog.txt",
                            FileMode.OpenOrCreate, FileAccess.Write);

                var logger = weightLogger;

                logger = new StreamWriter(output);

                logger.WriteLine($"{DateTime.Now.ToString("G")} Weight: {weight.ToString("N2")}kg" + Environment.NewLine);

                logger.Close();  */

                    string input = $"{DateTime.Now.ToString("G")}| Weight: {weight.ToString("N2")}lbs ;" + Environment.NewLine;

                logInput(path, input);
            }
            else
            {
                // If the parsing failed, display an error message
                MessageBox.Show("Invalid weight entered.");
            }
        }

        private void waterButton_Click(object sender, EventArgs e)
        {
            // Declare a variable to hold the parsed weight
            double weight;
            double water;

            // Try to parse the weight from the text in weightTextBox2
            if (Double.TryParse(weightTextBox2.Text, out weight))
            {
                // If the parsing succeeded, add the water to the ListBox, formatted to two decimal places
                if (Double.TryParse(waterTextBox.Text, out water))
                {
                    waterListBox.Items.Add(water.ToString("N2"));

                    string path = $@"{dataLocation}/WaterIntakeLog.txt";

                    string input = ($"{DateTime.Now.ToString("G")}| Intake: {water.ToString("N2")}L | Your daily water intake should be {(weight*0.67).ToString("F2")}L ;" + Environment.NewLine);

                    logInput(path, input);

                }
                else
                {
                    // If the parsing failed, display an error message
                    MessageBox.Show("Invalid water entered.");
                }

                // Calculate the daily water intake based on the weight entered by the user
                double dailyWaterIntake = weight * 0.67;
                dailyWaterIntakeLabel.Text = "Your daily water intake should be " + dailyWaterIntake.ToString("F2") + " L";
            }
            else
            {
                // If the weight parsing failed, display an error message in the dailyWaterIntakeLabel
                dailyWaterIntakeLabel.Text = "Invalid weight entered.";
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string exercise = exerciseComboBox.SelectedItem.ToString();
            int time;

            // Try to parse the input time, show an error message if it's not valid
            if (!int.TryParse(exerciseTimeTextBox.Text, out time))
            {
                MessageBox.Show("Please enter a valid time in minutes.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Calculate the calories burned based on the exercise and time
            int calories = 0;
            switch (exercise)
            {
                case "Walking":
                    calories = time * 5;
                    break;
                case "Jogging":
                    calories = time * 10;
                    break;
                case "Running":
                    calories = time * 15;
                    break;
                case "Jump-Roping":
                    calories = time * 12;
                    break;
                case "Swimming":
                    calories = time * 20;
                    break;
                case "Weight-Lifting":
                    calories = time * 8;
                    break;
            }

            // Display the calculated calories in the output label and add to the ListBox
            string result = $"You burned {calories} calories while {exercise.ToLower()} for {time} minutes.";
            caloriesCalculatedLabels.Text = result;
            exerciseListBox.Items.Add(result);

            string path = $@"{dataLocation}/ActivityLog.txt";
 
            string input = ($"{DateTime.Now.ToString("G")}| {result} ;" + Environment.NewLine);

            logInput(path, input);
        }


        private void dietButton_Click(object sender, EventArgs e)
        {
            bmiPanel.Visible = false;
            bmiPanel.Enabled = false;
            weightTrackingPanel.Visible = false;
            weightTrackingPanel.Enabled = false;
            waterIntakePanel.Visible = false;
            waterIntakePanel.Enabled = false;
            exercisePanel.Visible = false;
            exercisePanel.Enabled = false;
            defaultPanel.Visible = false;
            defaultPanel.Enabled = false;
            dietPanel.Enabled = true;
            dietPanel.Visible = true;
        }

        private void physicalActivityButton_Click(object sender, EventArgs e)
        {
            bmiPanel.Visible = false;
            bmiPanel.Enabled = false;
            weightTrackingPanel.Visible = false;
            weightTrackingPanel.Enabled = false;
            waterIntakePanel.Visible = false;
            waterIntakePanel.Enabled = false;
            exercisePanel.Visible = true;
            exercisePanel.Enabled = true;
            dietPanel.Visible = false;
            dietPanel.Enabled = false;
            defaultPanel.Visible = false;
            defaultPanel.Enabled = false;
        }

        private void calculateCaloriesGainedButton_Click(object sender, EventArgs e)
        {
            string foodName = foodNameTextBox.Text;
            int caloriesPerServing;

            // Try to parse the input calories, show an error message if it's not valid
            if (!int.TryParse(caloriesPerServingTextBox.Text, out caloriesPerServing))
            {
                MessageBox.Show("Please enter a valid number of calories per serving.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int servings;
            // Try to parse the input servings, show an error message if it's not valid
            if (!int.TryParse(foodServingsTextBox.Text, out servings))
            {
                MessageBox.Show("Please enter a valid number of servings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Calculate the total calories gained based on the food and servings
            int totalCalories = caloriesPerServing * servings;

            // Display the calculated calories in the output label and add to the ListBox
            string result = $"You gained {totalCalories} calories while eating {servings} servings of {foodName}. ;";
            caloriesResultLabel.Text = result;
            dietListBox.Items.Add(result);

            string path = $@"{dataLocation}/DietLog.txt";

            string input = ($"{DateTime.Now.ToString("G")}| {result}" + Environment.NewLine);

            logInput(path, input);

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TopPanel_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
    }
}
