﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Newtonsoft.Json;
using System.Globalization;
using System.Threading;

namespace FitnessTracker
{
    public partial class LoginForm : Form
    {
        List<User> userList;

        public LoginForm()
        {

            InitializeComponent();
            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en");
            //WindowState = FormWindowState.Minimized;
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void TopPanel_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void languageComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var changeLanguage = new ChangeLanguage();
            switch (languageComboBox.SelectedIndex)
            {
                case 0:
                    changeLanguage.UpdateConfig("language", "en");
                    Application.Restart();
                    break;

                case 1:
                    changeLanguage.UpdateConfig("language", "fr-CA");
                    Application.Restart();
                    break;
                case 2:
                    changeLanguage.UpdateConfig("language", "es");
                    Application.Restart();
                    break;
                case 3:
                    changeLanguage.UpdateConfig("language", "ar-SA");
                    Application.Restart();
                    break;
            }
        }

        // Close-Maximize-Minimize
        private void CloseIconButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /*private void MaximizeIconButton_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
                FormBorderStyle = FormBorderStyle.None;
                MaximizeIconButton.Text = "▣";
                //MaximizeIconButton.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            }
            else
            {
                WindowState = FormWindowState.Normal;
                MaximizeIconButton.Text = "▢";
                //MaximizeIconButton.IconChar = FontAwesome.Sharp.IconChar.Square;
            }
        }*/

        private void MinimizeIconButton_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
        private void loginButton_Click(object sender, EventArgs e)
        {
            //run a user and password check and if user exist + right password in the database, switch to
            //[accounttypepanel]Menu by setting it to Visible = true and setting loginPanel.Visible = false

            var jsonData = System.IO.File.ReadAllText(@"../../UserList.json");
            userList = JsonConvert.DeserializeObject<List<User>>(jsonData);

            Boolean userFound = false;

            foreach (User user in userList)
            {
                if (user.username == userTextBox.Text)
                {
                    if (user.password == passwordTextBox.Text)
                    {
                        switch (user.accType)
                        {
                            case "Client":
                                MainPage newForm = new MainPage(user.username);
                                this.Hide();
                                newForm.FormClosed += (s, args) => this.Show(); clearInput();
                                newForm.Show();
                                userFound = true;
                                break;
                           /* case "Admin":
                                //StaffForm newForm2 = new StaffForm();
                                this.Hide();
                                newForm2.FormClosed += (s, args) => Application.Exit();
                                newForm2.Show();
                                break;*/
                        }
                        errorLabel.Text = string.Empty;
                    }
                    else
                    {
                        errorLabel.Text = "Wrong user or password.";
                        return;
                    }
                }
                
            }

            if (userFound == false)
            {
 
                
                    errorLabel.Text = "Account does not exist, please create a new one.";
                    return;
                
            }

        
}

        private void createAccountButton_Click(object sender, EventArgs e)
        {
            //bool userCheck = false;
            bool passCheck = false;

            var jsonData = System.IO.File.ReadAllText(@"../../UserList.json");
            userList = JsonConvert.DeserializeObject<List<User>>(jsonData);

            // do a check with the username to see if it exists in the database.
            // if it does, change the errorLabel text and have it display it exist.

            for (int i = 0; i < userList.Count; i++)
            {
                if (userList[i].username == createUserTextBox.Text)
                {
                    MessageBox.Show("This user already exist." +
                "", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }


            if (createPassTextBox.Text.Equals(confirmPassTextBox.Text)) // confirm both passwords are the same
            {
                passCheck = true;
            }

            try // Check if the user properly added the information
            {
                if (passCheck == false || createUserTextBox.Text == string.Empty || createPassTextBox.Text == string.Empty || accTypeComboBox.Text == string.Empty)
                {
                    throw new Exception(); // throws an error if any of those checks fail
                }
            }
            catch (Exception)
            {
                MessageBox.Show("There is an error in the creation of this account." +
                    "Please verify that your inputs are correct", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var newAccount = new User();
            string user = createUserTextBox.Text;
            string pass = createPassTextBox.Text;
            string type = accTypeComboBox.Text;

            newAccount.username = user;
            newAccount.password = pass;
            newAccount.accType = type;
            newAccount.age = int.Parse(ageTextBox.Text);
            /*switch (accTypeComboBox.SelectedIndex)
            {

                case 0:
                    newAccount.username = user;
                    newAccount.password = pass;
                    newAccount.accType = type;
                    break;
                case 1:
                    
                    break;

            }*/
            if (tokenTextBox.Text != "123" && type == "Admin")
            {
                errorLabel2.Text = "Invalid token.";
                return;
            }

            userList.Add(newAccount);
            //add the newAccount to the database or whatever is registering the user.
            saveData();
            MessageBox.Show("Account created!", "New Account Made",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            createAccountPanel.Visible = false;
            loginPanel.Visible = true;

        }

        private void newAccButton_Click(object sender, EventArgs e)
        {
            loginPanel.Visible = false;
            createAccountPanel.Visible = true;
        }

        private void saveData()
        {
            string JSONresult = JsonConvert.SerializeObject(userList);
            string path = @"../../UserList.json";

            System.IO.File.WriteAllText(path, JSONresult);
        }

        private void clearInput()
        {
            createUserTextBox.Clear();
            createPassTextBox.Clear();
            confirmPassTextBox.Clear();
            userTextBox.Clear();
            passwordTextBox.Clear();
            accTypeComboBox.Text = "";
        }

        private void accTypeChange(object sender, EventArgs e)
        {
            if (accTypeComboBox.SelectedIndex == 1)
            {
                tokenPanel.Visible = !tokenPanel.Visible;
                tokenPanel.Enabled = !tokenPanel.Enabled;
            }
            else
            {
                tokenPanel.Visible = false;
                tokenPanel.Enabled = false;
            }
        }

        private void inputResetPass(object sender, EventArgs e)
        {
            passwordTextBox.Clear();
        }

        private void backToLoginButton_Click(object sender, EventArgs e)
        {
            createAccountPanel.Visible = false;
            loginPanel.Visible = true;
        }
    }
}
