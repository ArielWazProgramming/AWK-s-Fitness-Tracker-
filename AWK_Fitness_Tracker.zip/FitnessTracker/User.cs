﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessTracker
{
    class User
    {
        public string username;
        public string password;
        public string accType;

        public int age;
    }
}
