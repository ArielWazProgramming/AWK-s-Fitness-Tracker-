﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace FitnessTracker
{
    public partial class RegisterForm : Form
    {
        // Create a connection string for the SQL database
        private string connString = @"Data Source = (localdb)\MSSQLLocalDB;
            Initial Catalog = FitnessTracker; Integrated Security = True";

        public RegisterForm()
        {
            InitializeComponent();
        }
        private void languageComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var changeLanguage = new ChangeLanguage();
            switch (languageComboBox.SelectedIndex)
            {
                case 0:
                    changeLanguage.UpdateConfig("language", "en-US");
                    Application.Restart();
                    break;

                case 1:
                    changeLanguage.UpdateConfig("language", "fr-CA");
                    Application.Restart();
                    break;
                case 2:
                    changeLanguage.UpdateConfig("language", "es-ES");
                    Application.Restart();
                    break;
                case 3:
                    changeLanguage.UpdateConfig("language", "ar-SA");
                    Application.Restart();
                    break;
            }
        }
        private void registerButton_Click(object sender, EventArgs e)
        {
            // Get the user's information from the input fields
            string name = nameTextBox.Text;
            string email = emailTextBox.Text;
            string password = passwordTextBox.Text;
            int age = int.Parse(ageTextBox.Text);
            double height = double.Parse(heightTextBox.Text);
            double weight = double.Parse(weightTextBox.Text);

            // Insert the user's information into the database
            string query = "INSERT INTO Users (Name, Email, Password, Age, " +
                "Height, Weight) VALUES (@Name, @Email, @Password, @Age, @Height, @Weight)";

            using (SqlConnection conn = new SqlConnection(connString))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@Age", age);
                cmd.Parameters.AddWithValue("@Height", height);
                cmd.Parameters.AddWithValue("@Weight", weight);
                conn.Open();
                cmd.ExecuteNonQuery();
            }

            // Show a message to the user confirming their registration
            MessageBox.Show("Registration successful. Please log in.");

            //DashboardForm dashboard = new DashboardForm();
            //dashboard.Show();
            //this.Hide();
        }


    }

}

