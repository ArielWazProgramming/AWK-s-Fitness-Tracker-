﻿namespace FitnessTracker
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.languageComboBox = new System.Windows.Forms.ComboBox();
            this.loginPanel = new System.Windows.Forms.Panel();
            this.newAccButton = new System.Windows.Forms.Button();
            this.formLabel = new System.Windows.Forms.Label();
            this.loginButton = new System.Windows.Forms.Button();
            this.errorLabel = new System.Windows.Forms.Label();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.userLabel = new System.Windows.Forms.Label();
            this.userTextBox = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.createAccountPanel = new System.Windows.Forms.Panel();
            this.backToLoginButton = new System.Windows.Forms.Button();
            this.tokenPanel = new System.Windows.Forms.Panel();
            this.errorLabel2 = new System.Windows.Forms.Label();
            this.tokenTextBox = new System.Windows.Forms.TextBox();
            this.tokenLabel = new System.Windows.Forms.Label();
            this.createAccountButton = new System.Windows.Forms.Button();
            this.accTypeLabel = new System.Windows.Forms.Label();
            this.accTypeComboBox = new System.Windows.Forms.ComboBox();
            this.confirmPasswordLabel = new System.Windows.Forms.Label();
            this.confirmPassTextBox = new System.Windows.Forms.TextBox();
            this.newPasswordLabel = new System.Windows.Forms.Label();
            this.createPassTextBox = new System.Windows.Forms.TextBox();
            this.newUserLabel = new System.Windows.Forms.Label();
            this.createUserTextBox = new System.Windows.Forms.TextBox();
            this.ageLabel = new System.Windows.Forms.Label();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.languageLabel = new System.Windows.Forms.Label();
            this.TopPanel = new System.Windows.Forms.Panel();
            this.MinimizeIconButton = new System.Windows.Forms.Button();
            this.CloseIconButton = new System.Windows.Forms.Button();
            this.loginPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.createAccountPanel.SuspendLayout();
            this.tokenPanel.SuspendLayout();
            this.TopPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // languageComboBox
            // 
            resources.ApplyResources(this.languageComboBox, "languageComboBox");
            this.languageComboBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.languageComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.languageComboBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.languageComboBox.FormattingEnabled = true;
            this.languageComboBox.Items.AddRange(new object[] {
            resources.GetString("languageComboBox.Items"),
            resources.GetString("languageComboBox.Items1"),
            resources.GetString("languageComboBox.Items2"),
            resources.GetString("languageComboBox.Items3")});
            this.languageComboBox.Name = "languageComboBox";
            this.languageComboBox.SelectedIndexChanged += new System.EventHandler(this.languageComboBox_SelectedIndexChanged);
            // 
            // loginPanel
            // 
            resources.ApplyResources(this.loginPanel, "loginPanel");
            this.loginPanel.BackColor = System.Drawing.Color.Transparent;
            this.loginPanel.Controls.Add(this.newAccButton);
            this.loginPanel.Controls.Add(this.formLabel);
            this.loginPanel.Controls.Add(this.loginButton);
            this.loginPanel.Controls.Add(this.errorLabel);
            this.loginPanel.Controls.Add(this.passwordLabel);
            this.loginPanel.Controls.Add(this.passwordTextBox);
            this.loginPanel.Controls.Add(this.userLabel);
            this.loginPanel.Controls.Add(this.userTextBox);
            this.loginPanel.Controls.Add(this.pictureBox1);
            this.loginPanel.Name = "loginPanel";
            // 
            // newAccButton
            // 
            resources.ApplyResources(this.newAccButton, "newAccButton");
            this.newAccButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(26)))), ((int)(((byte)(28)))));
            this.newAccButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.newAccButton.Name = "newAccButton";
            this.newAccButton.UseVisualStyleBackColor = false;
            this.newAccButton.Click += new System.EventHandler(this.newAccButton_Click);
            // 
            // formLabel
            // 
            resources.ApplyResources(this.formLabel, "formLabel");
            this.formLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.formLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.formLabel.Name = "formLabel";
            // 
            // loginButton
            // 
            resources.ApplyResources(this.loginButton, "loginButton");
            this.loginButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.loginButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.loginButton.Name = "loginButton";
            this.loginButton.UseVisualStyleBackColor = false;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // errorLabel
            // 
            resources.ApplyResources(this.errorLabel, "errorLabel");
            this.errorLabel.ForeColor = System.Drawing.Color.Red;
            this.errorLabel.Name = "errorLabel";
            // 
            // passwordLabel
            // 
            resources.ApplyResources(this.passwordLabel, "passwordLabel");
            this.passwordLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.passwordLabel.Name = "passwordLabel";
            // 
            // passwordTextBox
            // 
            resources.ApplyResources(this.passwordTextBox, "passwordTextBox");
            this.passwordTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.passwordTextBox.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.UseSystemPasswordChar = true;
            // 
            // userLabel
            // 
            resources.ApplyResources(this.userLabel, "userLabel");
            this.userLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.userLabel.Name = "userLabel";
            // 
            // userTextBox
            // 
            resources.ApplyResources(this.userTextBox, "userTextBox");
            this.userTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.userTextBox.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.userTextBox.Name = "userTextBox";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox1.Image = global::FitnessTracker.Properties.Resources.puleBG;
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // createAccountPanel
            // 
            resources.ApplyResources(this.createAccountPanel, "createAccountPanel");
            this.createAccountPanel.BackColor = System.Drawing.Color.Transparent;
            this.createAccountPanel.Controls.Add(this.backToLoginButton);
            this.createAccountPanel.Controls.Add(this.tokenPanel);
            this.createAccountPanel.Controls.Add(this.createAccountButton);
            this.createAccountPanel.Controls.Add(this.accTypeLabel);
            this.createAccountPanel.Controls.Add(this.accTypeComboBox);
            this.createAccountPanel.Controls.Add(this.confirmPasswordLabel);
            this.createAccountPanel.Controls.Add(this.confirmPassTextBox);
            this.createAccountPanel.Controls.Add(this.newPasswordLabel);
            this.createAccountPanel.Controls.Add(this.createPassTextBox);
            this.createAccountPanel.Controls.Add(this.newUserLabel);
            this.createAccountPanel.Controls.Add(this.createUserTextBox);
            this.createAccountPanel.Controls.Add(this.ageLabel);
            this.createAccountPanel.Controls.Add(this.ageTextBox);
            this.createAccountPanel.Name = "createAccountPanel";
            // 
            // backToLoginButton
            // 
            resources.ApplyResources(this.backToLoginButton, "backToLoginButton");
            this.backToLoginButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.backToLoginButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.backToLoginButton.Name = "backToLoginButton";
            this.backToLoginButton.UseVisualStyleBackColor = false;
            this.backToLoginButton.Click += new System.EventHandler(this.backToLoginButton_Click);
            // 
            // tokenPanel
            // 
            resources.ApplyResources(this.tokenPanel, "tokenPanel");
            this.tokenPanel.Controls.Add(this.errorLabel2);
            this.tokenPanel.Controls.Add(this.tokenTextBox);
            this.tokenPanel.Controls.Add(this.tokenLabel);
            this.tokenPanel.Name = "tokenPanel";
            // 
            // errorLabel2
            // 
            resources.ApplyResources(this.errorLabel2, "errorLabel2");
            this.errorLabel2.BackColor = System.Drawing.Color.Transparent;
            this.errorLabel2.ForeColor = System.Drawing.Color.Red;
            this.errorLabel2.Name = "errorLabel2";
            // 
            // tokenTextBox
            // 
            resources.ApplyResources(this.tokenTextBox, "tokenTextBox");
            this.tokenTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.tokenTextBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.tokenTextBox.Name = "tokenTextBox";
            this.tokenTextBox.UseSystemPasswordChar = true;
            // 
            // tokenLabel
            // 
            resources.ApplyResources(this.tokenLabel, "tokenLabel");
            this.tokenLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.tokenLabel.Name = "tokenLabel";
            // 
            // createAccountButton
            // 
            resources.ApplyResources(this.createAccountButton, "createAccountButton");
            this.createAccountButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.createAccountButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.createAccountButton.Name = "createAccountButton";
            this.createAccountButton.UseVisualStyleBackColor = false;
            this.createAccountButton.Click += new System.EventHandler(this.createAccountButton_Click);
            // 
            // accTypeLabel
            // 
            resources.ApplyResources(this.accTypeLabel, "accTypeLabel");
            this.accTypeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.accTypeLabel.Name = "accTypeLabel";
            // 
            // accTypeComboBox
            // 
            resources.ApplyResources(this.accTypeComboBox, "accTypeComboBox");
            this.accTypeComboBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.accTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.accTypeComboBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.accTypeComboBox.FormattingEnabled = true;
            this.accTypeComboBox.Items.AddRange(new object[] {
            resources.GetString("accTypeComboBox.Items"),
            resources.GetString("accTypeComboBox.Items1")});
            this.accTypeComboBox.Name = "accTypeComboBox";
            this.accTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.accTypeChange);
            // 
            // confirmPasswordLabel
            // 
            resources.ApplyResources(this.confirmPasswordLabel, "confirmPasswordLabel");
            this.confirmPasswordLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.confirmPasswordLabel.Name = "confirmPasswordLabel";
            // 
            // confirmPassTextBox
            // 
            resources.ApplyResources(this.confirmPassTextBox, "confirmPassTextBox");
            this.confirmPassTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.confirmPassTextBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.confirmPassTextBox.Name = "confirmPassTextBox";
            this.confirmPassTextBox.UseSystemPasswordChar = true;
            // 
            // newPasswordLabel
            // 
            resources.ApplyResources(this.newPasswordLabel, "newPasswordLabel");
            this.newPasswordLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.newPasswordLabel.Name = "newPasswordLabel";
            // 
            // createPassTextBox
            // 
            resources.ApplyResources(this.createPassTextBox, "createPassTextBox");
            this.createPassTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.createPassTextBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.createPassTextBox.Name = "createPassTextBox";
            this.createPassTextBox.UseSystemPasswordChar = true;
            // 
            // newUserLabel
            // 
            resources.ApplyResources(this.newUserLabel, "newUserLabel");
            this.newUserLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.newUserLabel.Name = "newUserLabel";
            // 
            // createUserTextBox
            // 
            resources.ApplyResources(this.createUserTextBox, "createUserTextBox");
            this.createUserTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.createUserTextBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.createUserTextBox.Name = "createUserTextBox";
            // 
            // ageLabel
            // 
            resources.ApplyResources(this.ageLabel, "ageLabel");
            this.ageLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ageLabel.Name = "ageLabel";
            // 
            // ageTextBox
            // 
            resources.ApplyResources(this.ageTextBox, "ageTextBox");
            this.ageTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.ageTextBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.ageTextBox.Name = "ageTextBox";
            // 
            // languageLabel
            // 
            resources.ApplyResources(this.languageLabel, "languageLabel");
            this.languageLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.languageLabel.Name = "languageLabel";
            // 
            // TopPanel
            // 
            resources.ApplyResources(this.TopPanel, "TopPanel");
            this.TopPanel.BackColor = System.Drawing.Color.Black;
            this.TopPanel.Controls.Add(this.MinimizeIconButton);
            this.TopPanel.Controls.Add(this.CloseIconButton);
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TopPanel_MouseDown);
            // 
            // MinimizeIconButton
            // 
            resources.ApplyResources(this.MinimizeIconButton, "MinimizeIconButton");
            this.MinimizeIconButton.BackColor = System.Drawing.Color.DimGray;
            this.MinimizeIconButton.Name = "MinimizeIconButton";
            this.MinimizeIconButton.UseVisualStyleBackColor = false;
            this.MinimizeIconButton.Click += new System.EventHandler(this.MinimizeIconButton_Click);
            // 
            // CloseIconButton
            // 
            resources.ApplyResources(this.CloseIconButton, "CloseIconButton");
            this.CloseIconButton.BackColor = System.Drawing.Color.DimGray;
            this.CloseIconButton.Name = "CloseIconButton";
            this.CloseIconButton.UseVisualStyleBackColor = false;
            this.CloseIconButton.Click += new System.EventHandler(this.CloseIconButton_Click);
            // 
            // LoginForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Controls.Add(this.languageLabel);
            this.Controls.Add(this.languageComboBox);
            this.Controls.Add(this.loginPanel);
            this.Controls.Add(this.TopPanel);
            this.Controls.Add(this.createAccountPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoginForm";
            this.loginPanel.ResumeLayout(false);
            this.loginPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.createAccountPanel.ResumeLayout(false);
            this.createAccountPanel.PerformLayout();
            this.tokenPanel.ResumeLayout(false);
            this.tokenPanel.PerformLayout();
            this.TopPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox languageComboBox;
        private System.Windows.Forms.Panel loginPanel;
        private System.Windows.Forms.Button newAccButton;
        private System.Windows.Forms.Label formLabel;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Label errorLabel;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.TextBox userTextBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel TopPanel;
        private System.Windows.Forms.Button MinimizeIconButton;
        private System.Windows.Forms.Button CloseIconButton;
        private System.Windows.Forms.Panel createAccountPanel;
        private System.Windows.Forms.Button backToLoginButton;
        private System.Windows.Forms.Panel tokenPanel;
        private System.Windows.Forms.Label errorLabel2;
        private System.Windows.Forms.TextBox tokenTextBox;
        private System.Windows.Forms.Label tokenLabel;
        private System.Windows.Forms.Button createAccountButton;
        private System.Windows.Forms.Label accTypeLabel;
        private System.Windows.Forms.ComboBox accTypeComboBox;
        private System.Windows.Forms.Label confirmPasswordLabel;
        private System.Windows.Forms.TextBox confirmPassTextBox;
        private System.Windows.Forms.Label newPasswordLabel;
        private System.Windows.Forms.TextBox createPassTextBox;
        private System.Windows.Forms.Label newUserLabel;
        private System.Windows.Forms.TextBox createUserTextBox;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.TextBox ageTextBox;
        private System.Windows.Forms.Label languageLabel;
    }
}