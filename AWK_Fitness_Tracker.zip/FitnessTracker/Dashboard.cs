﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Xml.Linq;

namespace FitnessTracker
{
    public partial class DashboardForm : Form
    {
        // Create a connection string for the SQL database
        private string connString = @"Data Source = (localdb)\MSSQLLocalDB;
            Initial Catalog = FitnessTracker; Integrated Security = True";

        public DashboardForm()
        {
            InitializeComponent();
        }
        private void languageComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var changeLanguage = new ChangeLanguage();
            switch (languageComboBox.SelectedIndex)
            {
                case 0:
                    changeLanguage.UpdateConfig("language", "en-US");
                    Application.Restart();
                    break;

                case 1:
                    changeLanguage.UpdateConfig("language", "fr-CA");
                    Application.Restart();
                    break;
                case 2:
                    changeLanguage.UpdateConfig("language", "es-ES");
                    Application.Restart();
                    break;
                case 3:
                    changeLanguage.UpdateConfig("language", "ar-SA");
                    Application.Restart();
                    break;
            }
        }
        private void loginButton_Click(object sender, EventArgs e)
        {
            // Get the user's email and password from the input fields
            string email = emailTextBox.Text;
            string password = passwordTextBox.Text;

            // Validate the user's credentials by checking if they exist
            // in the database
            /*string query = "SELECT COUNT(*) FROM Users WHERE Email = @" +
                "Email AND Password = @Password";
            int result = 0;

            using (SqlConnection conn = new SqlConnection(connString))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                conn.Open();
                result = (int)cmd.ExecuteScalar();
            }
            */

            // If the credentials are valid, show the main dashboard form
            //if (result > 0)
            //{
                //MainPage dashboard = new MainPage();
                //dashboard.Show();
                this.Hide();
           // dashboard.FormClosing += DashBoardOpen;
           // }
           // else
           // {
           // MessageBox.Show("Invalid email or password.");
           //}
        }

        private void DashBoardOpen(object sender, FormClosingEventArgs e)
        {
            this.Show();
        }

        private void signUpButton_Click(object sender, EventArgs e)
        {
            RegisterForm register = new RegisterForm();
            register.Show();
            this.Hide();
        }
    }
}
