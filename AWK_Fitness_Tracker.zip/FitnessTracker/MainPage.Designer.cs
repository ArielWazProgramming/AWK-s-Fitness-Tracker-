﻿namespace FitnessTracker
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainPage));
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.bmiButton = new System.Windows.Forms.Button();
            this.weightTracking = new System.Windows.Forms.Button();
            this.waterIntakeButton = new System.Windows.Forms.Button();
            this.physicalActivityButton = new System.Windows.Forms.Button();
            this.dietButton = new System.Windows.Forms.Button();
            this.bmiPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.classificationButton = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.bmiResultTextBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.calculateBMIButton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.weightTrackingPanel = new System.Windows.Forms.Panel();
            this.weightListBox = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.addWeightButton = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.waterIntakePanel = new System.Windows.Forms.Panel();
            this.weightTextBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.waterListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.waterButton = new System.Windows.Forms.Button();
            this.waterTextBox = new System.Windows.Forms.TextBox();
            this.dailyWaterIntakeLabel = new System.Windows.Forms.Label();
            this.exercisePanel = new System.Windows.Forms.Panel();
            this.caloriesCalculatedLabels = new System.Windows.Forms.Label();
            this.exerciseComboBox = new System.Windows.Forms.ComboBox();
            this.exerciseTimeTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.randomLabel = new System.Windows.Forms.Label();
            this.exerciseListBox = new System.Windows.Forms.ListBox();
            this.dietPanel = new System.Windows.Forms.Panel();
            this.foodServingsTextBox = new System.Windows.Forms.TextBox();
            this.foodNameTextBox = new System.Windows.Forms.TextBox();
            this.caloriesResultLabel = new System.Windows.Forms.Label();
            this.caloriesPerServingTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.calculateCaloriesGainedButton = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.dietListBox = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.defaultPanel = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.logoutButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.TopPanel = new System.Windows.Forms.Panel();
            this.userLabel = new System.Windows.Forms.Label();
            this.bmiPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.weightTrackingPanel.SuspendLayout();
            this.waterIntakePanel.SuspendLayout();
            this.exercisePanel.SuspendLayout();
            this.dietPanel.SuspendLayout();
            this.defaultPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.TopPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // welcomeLabel
            // 
            resources.ApplyResources(this.welcomeLabel, "welcomeLabel");
            this.welcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.welcomeLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.welcomeLabel.Name = "welcomeLabel";
            // 
            // bmiButton
            // 
            resources.ApplyResources(this.bmiButton, "bmiButton");
            this.bmiButton.BackColor = System.Drawing.Color.Transparent;
            this.bmiButton.ForeColor = System.Drawing.SystemColors.Control;
            this.bmiButton.Name = "bmiButton";
            this.bmiButton.UseVisualStyleBackColor = false;
            this.bmiButton.Click += new System.EventHandler(this.bmiButton_Click);
            // 
            // weightTracking
            // 
            resources.ApplyResources(this.weightTracking, "weightTracking");
            this.weightTracking.BackColor = System.Drawing.Color.Transparent;
            this.weightTracking.ForeColor = System.Drawing.SystemColors.Control;
            this.weightTracking.Name = "weightTracking";
            this.weightTracking.UseVisualStyleBackColor = false;
            this.weightTracking.Click += new System.EventHandler(this.weightTracking_Click);
            // 
            // waterIntakeButton
            // 
            resources.ApplyResources(this.waterIntakeButton, "waterIntakeButton");
            this.waterIntakeButton.BackColor = System.Drawing.Color.Transparent;
            this.waterIntakeButton.ForeColor = System.Drawing.SystemColors.Control;
            this.waterIntakeButton.Name = "waterIntakeButton";
            this.waterIntakeButton.UseVisualStyleBackColor = false;
            this.waterIntakeButton.Click += new System.EventHandler(this.waterIntakeButton_Click);
            // 
            // physicalActivityButton
            // 
            resources.ApplyResources(this.physicalActivityButton, "physicalActivityButton");
            this.physicalActivityButton.BackColor = System.Drawing.Color.Transparent;
            this.physicalActivityButton.ForeColor = System.Drawing.SystemColors.Control;
            this.physicalActivityButton.Name = "physicalActivityButton";
            this.physicalActivityButton.UseVisualStyleBackColor = false;
            this.physicalActivityButton.Click += new System.EventHandler(this.physicalActivityButton_Click);
            // 
            // dietButton
            // 
            resources.ApplyResources(this.dietButton, "dietButton");
            this.dietButton.BackColor = System.Drawing.Color.Transparent;
            this.dietButton.ForeColor = System.Drawing.SystemColors.Control;
            this.dietButton.Name = "dietButton";
            this.dietButton.UseVisualStyleBackColor = false;
            this.dietButton.Click += new System.EventHandler(this.dietButton_Click);
            // 
            // bmiPanel
            // 
            resources.ApplyResources(this.bmiPanel, "bmiPanel");
            this.bmiPanel.BackColor = System.Drawing.Color.Transparent;
            this.bmiPanel.Controls.Add(this.pictureBox1);
            this.bmiPanel.Controls.Add(this.classificationButton);
            this.bmiPanel.Controls.Add(this.label1);
            this.bmiPanel.Controls.Add(this.label10);
            this.bmiPanel.Controls.Add(this.bmiResultTextBox);
            this.bmiPanel.Controls.Add(this.label14);
            this.bmiPanel.Controls.Add(this.calculateBMIButton);
            this.bmiPanel.Controls.Add(this.label11);
            this.bmiPanel.Controls.Add(this.heightTextBox);
            this.bmiPanel.Controls.Add(this.weightTextBox);
            this.bmiPanel.Controls.Add(this.label13);
            this.bmiPanel.Name = "bmiPanel";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.pictureBox1.BackgroundImage = global::FitnessTracker.Properties.Resources.BMI_Chart_Detailed;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.InitialImage = global::FitnessTracker.Properties.Resources.BMI_Chart_Detailed;
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // classificationButton
            // 
            resources.ApplyResources(this.classificationButton, "classificationButton");
            this.classificationButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.classificationButton.ForeColor = System.Drawing.SystemColors.Control;
            this.classificationButton.Name = "classificationButton";
            this.classificationButton.ReadOnly = true;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Name = "label1";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Name = "label10";
            // 
            // bmiResultTextBox
            // 
            resources.ApplyResources(this.bmiResultTextBox, "bmiResultTextBox");
            this.bmiResultTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.bmiResultTextBox.ForeColor = System.Drawing.SystemColors.Control;
            this.bmiResultTextBox.Name = "bmiResultTextBox";
            this.bmiResultTextBox.ReadOnly = true;
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Name = "label14";
            // 
            // calculateBMIButton
            // 
            resources.ApplyResources(this.calculateBMIButton, "calculateBMIButton");
            this.calculateBMIButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.calculateBMIButton.ForeColor = System.Drawing.SystemColors.Control;
            this.calculateBMIButton.Name = "calculateBMIButton";
            this.calculateBMIButton.UseVisualStyleBackColor = false;
            this.calculateBMIButton.Click += new System.EventHandler(this.calculateBMIButton_Click);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Name = "label11";
            // 
            // heightTextBox
            // 
            resources.ApplyResources(this.heightTextBox, "heightTextBox");
            this.heightTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.heightTextBox.ForeColor = System.Drawing.SystemColors.Control;
            this.heightTextBox.Name = "heightTextBox";
            // 
            // weightTextBox
            // 
            resources.ApplyResources(this.weightTextBox, "weightTextBox");
            this.weightTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.weightTextBox.ForeColor = System.Drawing.SystemColors.Control;
            this.weightTextBox.Name = "weightTextBox";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Name = "label13";
            // 
            // timeLabel
            // 
            resources.ApplyResources(this.timeLabel, "timeLabel");
            this.timeLabel.BackColor = System.Drawing.Color.Transparent;
            this.timeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.timeLabel.Name = "timeLabel";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // weightTrackingPanel
            // 
            resources.ApplyResources(this.weightTrackingPanel, "weightTrackingPanel");
            this.weightTrackingPanel.BackColor = System.Drawing.Color.Transparent;
            this.weightTrackingPanel.Controls.Add(this.weightListBox);
            this.weightTrackingPanel.Controls.Add(this.label4);
            this.weightTrackingPanel.Controls.Add(this.addWeightButton);
            this.weightTrackingPanel.Controls.Add(this.textBox4);
            this.weightTrackingPanel.Controls.Add(this.label6);
            this.weightTrackingPanel.Name = "weightTrackingPanel";
            // 
            // weightListBox
            // 
            resources.ApplyResources(this.weightListBox, "weightListBox");
            this.weightListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.weightListBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.weightListBox.ForeColor = System.Drawing.SystemColors.Control;
            this.weightListBox.FormattingEnabled = true;
            this.weightListBox.Name = "weightListBox";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Name = "label4";
            // 
            // addWeightButton
            // 
            resources.ApplyResources(this.addWeightButton, "addWeightButton");
            this.addWeightButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.addWeightButton.ForeColor = System.Drawing.SystemColors.Control;
            this.addWeightButton.Name = "addWeightButton";
            this.addWeightButton.UseVisualStyleBackColor = false;
            this.addWeightButton.Click += new System.EventHandler(this.addWeightButton_Click);
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.textBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.textBox4.Name = "textBox4";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Name = "label6";
            // 
            // waterIntakePanel
            // 
            resources.ApplyResources(this.waterIntakePanel, "waterIntakePanel");
            this.waterIntakePanel.BackColor = System.Drawing.Color.Transparent;
            this.waterIntakePanel.Controls.Add(this.weightTextBox2);
            this.waterIntakePanel.Controls.Add(this.label3);
            this.waterIntakePanel.Controls.Add(this.waterListBox);
            this.waterIntakePanel.Controls.Add(this.label2);
            this.waterIntakePanel.Controls.Add(this.waterButton);
            this.waterIntakePanel.Controls.Add(this.waterTextBox);
            this.waterIntakePanel.Controls.Add(this.dailyWaterIntakeLabel);
            this.waterIntakePanel.Name = "waterIntakePanel";
            // 
            // weightTextBox2
            // 
            resources.ApplyResources(this.weightTextBox2, "weightTextBox2");
            this.weightTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.weightTextBox2.ForeColor = System.Drawing.SystemColors.Window;
            this.weightTextBox2.Name = "weightTextBox2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Name = "label3";
            // 
            // waterListBox
            // 
            resources.ApplyResources(this.waterListBox, "waterListBox");
            this.waterListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.waterListBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.waterListBox.ForeColor = System.Drawing.SystemColors.Window;
            this.waterListBox.FormattingEnabled = true;
            this.waterListBox.Name = "waterListBox";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Name = "label2";
            // 
            // waterButton
            // 
            resources.ApplyResources(this.waterButton, "waterButton");
            this.waterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.waterButton.ForeColor = System.Drawing.SystemColors.Window;
            this.waterButton.Name = "waterButton";
            this.waterButton.UseVisualStyleBackColor = false;
            this.waterButton.Click += new System.EventHandler(this.waterButton_Click);
            // 
            // waterTextBox
            // 
            resources.ApplyResources(this.waterTextBox, "waterTextBox");
            this.waterTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.waterTextBox.ForeColor = System.Drawing.SystemColors.Window;
            this.waterTextBox.Name = "waterTextBox";
            // 
            // dailyWaterIntakeLabel
            // 
            resources.ApplyResources(this.dailyWaterIntakeLabel, "dailyWaterIntakeLabel");
            this.dailyWaterIntakeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dailyWaterIntakeLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.dailyWaterIntakeLabel.Name = "dailyWaterIntakeLabel";
            // 
            // exercisePanel
            // 
            resources.ApplyResources(this.exercisePanel, "exercisePanel");
            this.exercisePanel.BackColor = System.Drawing.Color.Transparent;
            this.exercisePanel.Controls.Add(this.caloriesCalculatedLabels);
            this.exercisePanel.Controls.Add(this.exerciseComboBox);
            this.exercisePanel.Controls.Add(this.exerciseTimeTextBox);
            this.exercisePanel.Controls.Add(this.label5);
            this.exercisePanel.Controls.Add(this.label7);
            this.exercisePanel.Controls.Add(this.button1);
            this.exercisePanel.Controls.Add(this.randomLabel);
            this.exercisePanel.Controls.Add(this.exerciseListBox);
            this.exercisePanel.Name = "exercisePanel";
            // 
            // caloriesCalculatedLabels
            // 
            resources.ApplyResources(this.caloriesCalculatedLabels, "caloriesCalculatedLabels");
            this.caloriesCalculatedLabels.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.caloriesCalculatedLabels.ForeColor = System.Drawing.SystemColors.Control;
            this.caloriesCalculatedLabels.Name = "caloriesCalculatedLabels";
            // 
            // exerciseComboBox
            // 
            resources.ApplyResources(this.exerciseComboBox, "exerciseComboBox");
            this.exerciseComboBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.exerciseComboBox.ForeColor = System.Drawing.SystemColors.Control;
            this.exerciseComboBox.FormattingEnabled = true;
            this.exerciseComboBox.Items.AddRange(new object[] {
            resources.GetString("exerciseComboBox.Items"),
            resources.GetString("exerciseComboBox.Items1"),
            resources.GetString("exerciseComboBox.Items2"),
            resources.GetString("exerciseComboBox.Items3"),
            resources.GetString("exerciseComboBox.Items4"),
            resources.GetString("exerciseComboBox.Items5")});
            this.exerciseComboBox.Name = "exerciseComboBox";
            // 
            // exerciseTimeTextBox
            // 
            resources.ApplyResources(this.exerciseTimeTextBox, "exerciseTimeTextBox");
            this.exerciseTimeTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.exerciseTimeTextBox.ForeColor = System.Drawing.SystemColors.Control;
            this.exerciseTimeTextBox.Name = "exerciseTimeTextBox";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Name = "label5";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Name = "label7";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // randomLabel
            // 
            resources.ApplyResources(this.randomLabel, "randomLabel");
            this.randomLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.randomLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.randomLabel.Name = "randomLabel";
            // 
            // exerciseListBox
            // 
            resources.ApplyResources(this.exerciseListBox, "exerciseListBox");
            this.exerciseListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.exerciseListBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.exerciseListBox.ForeColor = System.Drawing.SystemColors.Control;
            this.exerciseListBox.FormattingEnabled = true;
            this.exerciseListBox.Name = "exerciseListBox";
            // 
            // dietPanel
            // 
            resources.ApplyResources(this.dietPanel, "dietPanel");
            this.dietPanel.BackColor = System.Drawing.Color.Transparent;
            this.dietPanel.Controls.Add(this.foodServingsTextBox);
            this.dietPanel.Controls.Add(this.foodNameTextBox);
            this.dietPanel.Controls.Add(this.caloriesResultLabel);
            this.dietPanel.Controls.Add(this.caloriesPerServingTextBox);
            this.dietPanel.Controls.Add(this.label9);
            this.dietPanel.Controls.Add(this.label12);
            this.dietPanel.Controls.Add(this.calculateCaloriesGainedButton);
            this.dietPanel.Controls.Add(this.label15);
            this.dietPanel.Controls.Add(this.dietListBox);
            this.dietPanel.Controls.Add(this.label8);
            this.dietPanel.Name = "dietPanel";
            // 
            // foodServingsTextBox
            // 
            resources.ApplyResources(this.foodServingsTextBox, "foodServingsTextBox");
            this.foodServingsTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.foodServingsTextBox.ForeColor = System.Drawing.SystemColors.Control;
            this.foodServingsTextBox.Name = "foodServingsTextBox";
            // 
            // foodNameTextBox
            // 
            resources.ApplyResources(this.foodNameTextBox, "foodNameTextBox");
            this.foodNameTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.foodNameTextBox.ForeColor = System.Drawing.SystemColors.Control;
            this.foodNameTextBox.Name = "foodNameTextBox";
            // 
            // caloriesResultLabel
            // 
            resources.ApplyResources(this.caloriesResultLabel, "caloriesResultLabel");
            this.caloriesResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.caloriesResultLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.caloriesResultLabel.Name = "caloriesResultLabel";
            // 
            // caloriesPerServingTextBox
            // 
            resources.ApplyResources(this.caloriesPerServingTextBox, "caloriesPerServingTextBox");
            this.caloriesPerServingTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.caloriesPerServingTextBox.ForeColor = System.Drawing.SystemColors.Control;
            this.caloriesPerServingTextBox.Name = "caloriesPerServingTextBox";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Name = "label9";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Name = "label12";
            // 
            // calculateCaloriesGainedButton
            // 
            resources.ApplyResources(this.calculateCaloriesGainedButton, "calculateCaloriesGainedButton");
            this.calculateCaloriesGainedButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.calculateCaloriesGainedButton.ForeColor = System.Drawing.SystemColors.Control;
            this.calculateCaloriesGainedButton.Name = "calculateCaloriesGainedButton";
            this.calculateCaloriesGainedButton.UseVisualStyleBackColor = false;
            this.calculateCaloriesGainedButton.Click += new System.EventHandler(this.calculateCaloriesGainedButton_Click);
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Name = "label15";
            // 
            // dietListBox
            // 
            resources.ApplyResources(this.dietListBox, "dietListBox");
            this.dietListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.dietListBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dietListBox.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.dietListBox.FormattingEnabled = true;
            this.dietListBox.Name = "dietListBox";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Name = "label8";
            // 
            // defaultPanel
            // 
            resources.ApplyResources(this.defaultPanel, "defaultPanel");
            this.defaultPanel.BackColor = System.Drawing.Color.Transparent;
            this.defaultPanel.Controls.Add(this.pictureBox2);
            this.defaultPanel.Name = "defaultPanel";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Image = global::FitnessTracker.Properties.Resources.machocat;
            this.pictureBox2.InitialImage = global::FitnessTracker.Properties.Resources.Liftingpfp;
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.userLabel);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.logoutButton);
            this.panel1.Controls.Add(this.exitButton);
            this.panel1.Controls.Add(this.weightTracking);
            this.panel1.Controls.Add(this.bmiButton);
            this.panel1.Controls.Add(this.waterIntakeButton);
            this.panel1.Controls.Add(this.physicalActivityButton);
            this.panel1.Controls.Add(this.welcomeLabel);
            this.panel1.Controls.Add(this.dietButton);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Name = "panel1";
            // 
            // pictureBox4
            // 
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.BackgroundImage = global::FitnessTracker.Properties.Resources.logout;
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.BackgroundImage = global::FitnessTracker.Properties.Resources.shutdown_icon_14_256;
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // logoutButton
            // 
            resources.ApplyResources(this.logoutButton, "logoutButton");
            this.logoutButton.BackColor = System.Drawing.Color.Transparent;
            this.logoutButton.ForeColor = System.Drawing.SystemColors.Control;
            this.logoutButton.Name = "logoutButton";
            this.logoutButton.UseVisualStyleBackColor = false;
            this.logoutButton.Click += new System.EventHandler(this.logoutButton_Click);
            // 
            // exitButton
            // 
            resources.ApplyResources(this.exitButton, "exitButton");
            this.exitButton.BackColor = System.Drawing.Color.Transparent;
            this.exitButton.ForeColor = System.Drawing.SystemColors.Control;
            this.exitButton.Name = "exitButton";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // pictureBox5
            // 
            resources.ApplyResources(this.pictureBox5, "pictureBox5");
            this.pictureBox5.BackgroundImage = global::FitnessTracker.Properties.Resources.emblem;
            this.pictureBox5.Image = global::FitnessTracker.Properties.Resources.emblem;
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.TabStop = false;
            // 
            // TopPanel
            // 
            resources.ApplyResources(this.TopPanel, "TopPanel");
            this.TopPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.TopPanel.Controls.Add(this.timeLabel);
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TopPanel_MouseDown);
            // 
            // userLabel
            // 
            resources.ApplyResources(this.userLabel, "userLabel");
            this.userLabel.BackColor = System.Drawing.Color.Transparent;
            this.userLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.userLabel.Name = "userLabel";
            // 
            // MainPage
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FitnessTracker.Properties.Resources.darkbackground;
            this.Controls.Add(this.defaultPanel);
            this.Controls.Add(this.exercisePanel);
            this.Controls.Add(this.TopPanel);
            this.Controls.Add(this.dietPanel);
            this.Controls.Add(this.waterIntakePanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.weightTrackingPanel);
            this.Controls.Add(this.bmiPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainPage";
            this.Load += new System.EventHandler(this.MainPage_Load);
            this.bmiPanel.ResumeLayout(false);
            this.bmiPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.weightTrackingPanel.ResumeLayout(false);
            this.weightTrackingPanel.PerformLayout();
            this.waterIntakePanel.ResumeLayout(false);
            this.waterIntakePanel.PerformLayout();
            this.exercisePanel.ResumeLayout(false);
            this.exercisePanel.PerformLayout();
            this.dietPanel.ResumeLayout(false);
            this.dietPanel.PerformLayout();
            this.defaultPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.TopPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Button bmiButton;
        private System.Windows.Forms.Button weightTracking;
        private System.Windows.Forms.Button waterIntakeButton;
        private System.Windows.Forms.Button physicalActivityButton;
        private System.Windows.Forms.Button dietButton;
        private System.Windows.Forms.Panel bmiPanel;
        private System.Windows.Forms.TextBox classificationButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox bmiResultTextBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button calculateBMIButton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel weightTrackingPanel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button addWeightButton;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox weightListBox;
        private System.Windows.Forms.Panel waterIntakePanel;
        private System.Windows.Forms.ListBox waterListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button waterButton;
        private System.Windows.Forms.Label dailyWaterIntakeLabel;
        private System.Windows.Forms.TextBox weightTextBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel exercisePanel;
        private System.Windows.Forms.ListBox exerciseListBox;
        private System.Windows.Forms.TextBox waterTextBox;
        private System.Windows.Forms.Label caloriesCalculatedLabels;
        private System.Windows.Forms.ComboBox exerciseComboBox;
        private System.Windows.Forms.TextBox exerciseTimeTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label randomLabel;
        private System.Windows.Forms.Panel dietPanel;
        private System.Windows.Forms.Label caloriesResultLabel;
        private System.Windows.Forms.TextBox caloriesPerServingTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button calculateCaloriesGainedButton;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox dietListBox;
        private System.Windows.Forms.TextBox foodNameTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox foodServingsTextBox;
        private System.Windows.Forms.Panel defaultPanel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button logoutButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel TopPanel;
        private System.Windows.Forms.Label userLabel;
    }
}